--
-- PostgreSQL database dump
--

\restrict izVadgbJjtHYaXqKcKLUZXAvEDbzpY5qvSNbZaMzcjNrD4VyQDwsj1AXzs6enOg

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg13+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: efficiency_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.efficiency_points (
    id integer NOT NULL,
    fan_id integer NOT NULL,
    flow double precision NOT NULL,
    efficiency_centre double precision,
    efficiency_lower_end double precision,
    efficiency_higher_end double precision,
    permissible_use double precision
);


--
-- Name: efficiency_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.efficiency_points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: efficiency_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.efficiency_points_id_seq OWNED BY public.efficiency_points.id;


--
-- Name: fans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fans (
    id integer NOT NULL,
    manufacturer character varying(255) NOT NULL,
    model character varying(255) NOT NULL,
    notes text,
    mounting_style character varying(255),
    discharge_type character varying(255),
    graph_image_path character varying(512),
    show_rpm_band_shading boolean NOT NULL,
    diameter_mm double precision,
    max_rpm double precision
);


--
-- Name: fans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fans_id_seq OWNED BY public.fans.id;


--
-- Name: product_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_images (
    id integer NOT NULL,
    fan_id integer NOT NULL,
    file_name character varying(512) NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: product_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_images_id_seq OWNED BY public.product_images.id;


--
-- Name: rpm_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rpm_lines (
    id integer NOT NULL,
    fan_id integer NOT NULL,
    rpm double precision NOT NULL
);


--
-- Name: rpm_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rpm_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rpm_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rpm_lines_id_seq OWNED BY public.rpm_lines.id;


--
-- Name: rpm_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rpm_points (
    id integer NOT NULL,
    fan_id integer NOT NULL,
    rpm_line_id integer NOT NULL,
    flow double precision NOT NULL,
    pressure double precision NOT NULL
);


--
-- Name: rpm_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rpm_points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rpm_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rpm_points_id_seq OWNED BY public.rpm_points.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    password_hash character varying(1024) NOT NULL,
    is_admin boolean NOT NULL,
    is_active boolean NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: efficiency_points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.efficiency_points ALTER COLUMN id SET DEFAULT nextval('public.efficiency_points_id_seq'::regclass);


--
-- Name: fans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fans ALTER COLUMN id SET DEFAULT nextval('public.fans_id_seq'::regclass);


--
-- Name: product_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images ALTER COLUMN id SET DEFAULT nextval('public.product_images_id_seq'::regclass);


--
-- Name: rpm_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_lines ALTER COLUMN id SET DEFAULT nextval('public.rpm_lines_id_seq'::regclass);


--
-- Name: rpm_points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_points ALTER COLUMN id SET DEFAULT nextval('public.rpm_points_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: efficiency_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.efficiency_points (id, fan_id, flow, efficiency_centre, efficiency_lower_end, efficiency_higher_end, permissible_use) FROM stdin;
3	1	417	22	\N	\N	\N
4	1	553	34	\N	\N	\N
5	1	870	66	\N	\N	\N
9	1	922	76	\N	\N	\N
12	1	0	0	\N	\N	\N
13	1	738	48	\N	\N	\N
14	1	975	87	\N	\N	\N
75	1	0	\N	\N	\N	0
76	1	176	\N	\N	\N	59
77	1	69	\N	\N	\N	11
78	1	244	\N	\N	\N	96
79	1	125	\N	\N	\N	30
80	1	614	\N	94	\N	\N
81	1	593	\N	76	\N	\N
82	1	548	\N	58	\N	\N
83	1	540	\N	51	\N	\N
84	1	466	\N	37	\N	\N
85	1	338	\N	24	\N	\N
86	1	0	\N	0	\N	\N
87	1	1236	\N	\N	64	\N
88	1	1150	\N	\N	53	\N
89	1	1040	\N	\N	46	\N
90	1	951	\N	\N	36	\N
91	1	643	\N	\N	25	\N
92	1	389	\N	\N	14	\N
93	1	0	\N	\N	0	\N
16	2	383	30	\N	\N	\N
17	2	683	52	\N	\N	\N
19	2	1021	74	\N	\N	\N
20	2	0	0	0	0	0
94	2	210	\N	30	\N	\N
95	2	505	\N	60	\N	\N
96	2	807	\N	88	\N	\N
97	2	216	\N	\N	14	\N
98	2	436	\N	\N	24	\N
99	2	838	\N	\N	42	\N
100	2	1169	\N	\N	59	\N
101	2	53	\N	\N	\N	24
102	2	87	\N	\N	\N	80
103	2	103	\N	\N	\N	95
104	2	77	\N	\N	\N	48
26	3	246	24	\N	\N	\N
27	3	650	52	\N	\N	\N
29	3	898	84	\N	\N	\N
34	3	0	0	0	0	0
105	3	79	\N	\N	\N	41
106	3	88	\N	\N	\N	95
107	3	127	\N	20	\N	\N
108	3	453	\N	\N	22	\N
109	3	816	\N	\N	39	\N
110	3	1096	\N	\N	61	\N
111	3	551	\N	94	\N	\N
112	3	167	\N	\N	8	\N
113	3	395	\N	52	\N	\N
35	4	0	0	0	0	0
36	4	374	31	\N	\N	\N
37	4	870	58	\N	\N	\N
38	4	1032	81	\N	\N	\N
114	4	68	\N	3	\N	\N
115	4	338	\N	17	\N	\N
116	4	775	\N	28	\N	\N
117	4	40	\N	\N	8	\N
118	4	1119	\N	54	\N	\N
119	4	428	\N	\N	52	\N
120	4	1230	\N	64	\N	\N
121	4	673	\N	\N	78	\N
122	4	784	\N	\N	92	\N
45	5	70	30	\N	\N	\N
46	5	210	42	\N	\N	\N
47	5	540	55	\N	\N	\N
48	5	690	66	\N	\N	\N
49	5	820	75	\N	\N	\N
50	5	75	31	\N	\N	\N
51	5	390	46	\N	\N	\N
52	5	720	60	\N	\N	\N
53	5	920	91	\N	\N	\N
54	5	85	33	\N	\N	\N
55	6	100	34	\N	\N	\N
56	6	360	50	\N	\N	\N
57	6	900	60	\N	\N	\N
58	6	1080	72	\N	\N	\N
59	6	1260	82	\N	\N	\N
60	6	90	33	\N	\N	\N
61	6	650	48	\N	\N	\N
62	6	1030	63	\N	\N	\N
63	6	1320	96	\N	\N	\N
64	6	105	35	\N	\N	\N
65	7	95	31	\N	\N	\N
66	7	280	43	\N	\N	\N
67	7	720	56	\N	\N	\N
68	7	890	67	\N	\N	\N
69	7	1040	77	\N	\N	\N
70	7	85	32	\N	\N	\N
71	7	520	47	\N	\N	\N
72	7	880	62	\N	\N	\N
73	7	1120	93	\N	\N	\N
74	7	100	33	\N	\N	\N
\.


--
-- Data for Name: fans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fans (id, manufacturer, model, notes, mounting_style, discharge_type, graph_image_path, show_rpm_band_shading, diameter_mm, max_rpm) FROM stdin;
1	Example	Fan-1	Seed data for MVP	roof mounted	vertical discharge	/app/data/product_graphs/graph_example_fan_1.png	f	\N	\N
2	Test	100 series	Additional test fan	inline	vertical discharge	/app/data/product_graphs/graph_test_100_series.png	f	\N	\N
3	AeroFlow Dynamics	AFD-2200X	General purpose centrifugal blower	roof mounted	side discharge	/app/data/product_graphs/graph_aeroflow_dynamics_afd_2200x.png	t	\N	\N
4	Ventis Industrial	VI-XR180	High pressure industrial duct fan	inline	side discharge	/app/data/product_graphs/graph_ventis_industrial_vi_xr180.png	f	\N	\N
5	Helios Air Systems	HAS-900T	High efficiency HVAC fan	\N	\N	/app/data/product_graphs/graph_helios_air_systems_has_900t.png	t	\N	\N
6	NordWind Engineering	NW-3000C	High speed centrifugal unit	\N	\N	/app/data/product_graphs/graph_nordwind_engineering_nw_3000c.png	t	\N	\N
7	Atlas Ventilation	AV-M520	Medium pressure duct fan	\N	\N	/app/data/product_graphs/graph_atlas_ventilation_av_m520.png	t	\N	\N
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_images (id, fan_id, file_name, sort_order) FROM stdin;
1	1	pic_example_fan_1_1.png	0
3	2	pic_test_100_series_1.png	0
2	3	pic_aeroflow_dynamics_afd_2200x_1.png	0
\.


--
-- Data for Name: rpm_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rpm_lines (id, fan_id, rpm) FROM stdin;
1	1	1000
2	1	1500
3	1	2000
4	2	1200
5	2	1800
6	2	2400
7	3	1000
8	3	1500
9	3	2100
10	4	1400
11	4	2000
12	4	2600
13	5	900
14	5	1400
15	5	2000
16	6	1600
17	6	2200
18	6	3000
19	7	1100
20	7	1700
21	7	2300
\.


--
-- Data for Name: rpm_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rpm_points (id, fan_id, rpm_line_id, flow, pressure) FROM stdin;
1	1	1	147	136
2	1	1	516	131
3	1	1	801	106
4	1	1	989	74
5	1	1	1155	1
6	1	2	190	220
7	1	2	537	218
8	1	2	781	197
9	1	2	1179	107
10	1	2	1336	0
11	1	3	239	300
12	1	3	614	297
13	1	3	977	275
14	1	3	1238	204
15	1	3	1450	0
106	1	3	1116	244
107	1	2	1091	140
16	2	4	72	94
17	2	4	293	96
18	2	4	800	80
19	2	4	958	50
20	2	4	1106	0
21	2	5	83	158
22	2	5	516	158
23	2	5	900	139
24	2	5	1186	72
25	2	5	1455	0
26	2	6	96	218
27	2	6	676	216
28	2	6	1000	178
29	2	6	1310	101
30	2	6	1640	0
31	3	7	80	85
32	3	7	240	85
33	3	7	650	70
34	3	7	810	45
35	3	7	950	0
36	3	8	87	135
37	3	8	430	135
38	3	8	780	115
39	3	8	1030	60
40	3	8	1220	0
41	3	9	91	185
42	3	9	583	182
43	3	9	930	160
44	3	9	1180	95
45	3	9	1490	0
46	4	10	110	120
47	4	10	350	120
48	4	10	870	100
49	4	10	1050	60
50	4	10	1230	0
51	4	11	95	185
52	4	11	610	185
53	4	11	960	150
54	4	11	1240	85
55	4	11	1500	0
56	4	12	105	255
57	4	12	720	260
58	4	12	1120	210
59	4	12	1430	120
60	4	12	1780	0
61	5	13	70	70
62	5	13	210	70
63	5	13	540	60
64	5	13	690	38
65	5	13	820	0
66	5	14	75	115
67	5	14	390	115
68	5	14	720	95
69	5	14	920	55
70	5	14	1080	0
71	5	15	85	170
72	5	15	540	175
73	5	15	860	140
74	5	15	1100	80
75	5	15	1380	0
76	6	16	100	145
77	6	16	360	145
78	6	16	900	120
79	6	16	1080	70
80	6	16	1260	0
81	6	17	90	205
82	6	17	650	205
83	6	17	1030	170
84	6	17	1320	95
85	6	17	1600	0
86	6	18	105	290
87	6	18	820	295
88	6	18	1250	235
89	6	18	1590	140
90	6	18	1960	0
91	7	19	95	90
92	7	19	280	90
93	7	19	720	75
94	7	19	890	48
95	7	19	1040	0
96	7	20	85	145
97	7	20	520	145
98	7	20	880	120
99	7	20	1120	68
100	7	20	1380	0
101	7	21	100	210
102	7	21	690	215
103	7	21	1040	175
104	7	21	1330	100
105	7	21	1660	0
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password_hash, is_admin, is_active) FROM stdin;
\.


--
-- Name: efficiency_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.efficiency_points_id_seq', 122, true);


--
-- Name: fans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fans_id_seq', 7, true);


--
-- Name: product_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_images_id_seq', 3, true);


--
-- Name: rpm_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rpm_lines_id_seq', 21, true);


--
-- Name: rpm_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rpm_points_id_seq', 107, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: efficiency_points efficiency_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.efficiency_points
    ADD CONSTRAINT efficiency_points_pkey PRIMARY KEY (id);


--
-- Name: fans fans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fans
    ADD CONSTRAINT fans_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: rpm_lines rpm_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_lines
    ADD CONSTRAINT rpm_lines_pkey PRIMARY KEY (id);


--
-- Name: rpm_points rpm_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_points
    ADD CONSTRAINT rpm_points_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_efficiency_points_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_efficiency_points_id ON public.efficiency_points USING btree (id);


--
-- Name: ix_fans_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fans_id ON public.fans USING btree (id);


--
-- Name: ix_product_images_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_images_id ON public.product_images USING btree (id);


--
-- Name: ix_rpm_lines_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rpm_lines_id ON public.rpm_lines USING btree (id);


--
-- Name: ix_rpm_points_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rpm_points_id ON public.rpm_points USING btree (id);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: efficiency_points efficiency_points_fan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.efficiency_points
    ADD CONSTRAINT efficiency_points_fan_id_fkey FOREIGN KEY (fan_id) REFERENCES public.fans(id);


--
-- Name: product_images product_images_fan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_fan_id_fkey FOREIGN KEY (fan_id) REFERENCES public.fans(id);


--
-- Name: rpm_lines rpm_lines_fan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_lines
    ADD CONSTRAINT rpm_lines_fan_id_fkey FOREIGN KEY (fan_id) REFERENCES public.fans(id);


--
-- Name: rpm_points rpm_points_fan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_points
    ADD CONSTRAINT rpm_points_fan_id_fkey FOREIGN KEY (fan_id) REFERENCES public.fans(id);


--
-- Name: rpm_points rpm_points_rpm_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_points
    ADD CONSTRAINT rpm_points_rpm_line_id_fkey FOREIGN KEY (rpm_line_id) REFERENCES public.rpm_lines(id);


--
-- PostgreSQL database dump complete
--

\unrestrict izVadgbJjtHYaXqKcKLUZXAvEDbzpY5qvSNbZaMzcjNrD4VyQDwsj1AXzs6enOg

