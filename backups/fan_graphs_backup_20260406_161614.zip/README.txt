Fan Graphs backup bundle
Generated: 20260406_161614
Mode: compose
Env file: .env.deploy

Contents:
- postgres_dump.sql : PostgreSQL database dump
- data/product_images : uploaded product images (if present)
- data/product_graphs : generated graph images (if present)
- data/product_pdfs : future PDF assets (if present)
- wordpress_dump.sql : WordPress MariaDB dump (if present)
- wordpress/wp-content.tar : WordPress content volume snapshot (if present)
