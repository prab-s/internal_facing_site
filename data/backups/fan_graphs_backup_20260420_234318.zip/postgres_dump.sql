--
-- PostgreSQL database dump
--

\restrict GY5HHHMYVLKo3Sc8Pn1fAU5OIAtV28e5DaGtu43gvinMzPtfu495uwmW1dOOPja

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg13+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_settings (
    id integer NOT NULL,
    band_graph_background_color character varying(32),
    band_graph_label_text_color character varying(32)
);


--
-- Name: app_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.app_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: app_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.app_settings_id_seq OWNED BY public.app_settings.id;


--
-- Name: efficiency_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.efficiency_points (
    id integer NOT NULL,
    product_id integer NOT NULL,
    flow double precision NOT NULL,
    efficiency_centre double precision,
    efficiency_lower_end double precision,
    efficiency_higher_end double precision,
    permissible_use double precision
);


--
-- Name: efficiency_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.efficiency_points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: efficiency_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.efficiency_points_id_seq OWNED BY public.efficiency_points.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    model character varying(255) NOT NULL,
    mounting_style character varying(255),
    discharge_type character varying(255),
    graph_image_path character varying(512),
    show_rpm_band_shading boolean NOT NULL,
    band_graph_background_color character varying(32),
    band_graph_label_text_color character varying(32),
    band_graph_faded_opacity double precision,
    band_graph_permissible_label_color character varying(32),
    product_type_id integer,
    comments_html text,
    series_name character varying(255),
    series_id integer,
    template_id character varying(128),
    description1_html text,
    description2_html text,
    description3_html text
);


--
-- Name: fans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fans_id_seq OWNED BY public.products.id;


--
-- Name: product_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_images (
    id integer NOT NULL,
    product_id integer NOT NULL,
    file_name character varying(512) NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: product_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_images_id_seq OWNED BY public.product_images.id;


--
-- Name: product_parameter_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_parameter_groups (
    id integer NOT NULL,
    product_id integer NOT NULL,
    group_name character varying(255) NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: product_parameter_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_parameter_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_parameter_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_parameter_groups_id_seq OWNED BY public.product_parameter_groups.id;


--
-- Name: product_parameters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_parameters (
    id integer NOT NULL,
    group_id integer NOT NULL,
    parameter_name character varying(255) NOT NULL,
    sort_order integer NOT NULL,
    value_string text,
    value_number double precision,
    unit character varying(64)
);


--
-- Name: product_parameters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_parameters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_parameters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_parameters_id_seq OWNED BY public.product_parameters.id;


--
-- Name: product_type_parameter_group_presets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_type_parameter_group_presets (
    id integer NOT NULL,
    product_type_id integer NOT NULL,
    group_name character varying(255) NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: product_type_parameter_group_presets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_type_parameter_group_presets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_type_parameter_group_presets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_type_parameter_group_presets_id_seq OWNED BY public.product_type_parameter_group_presets.id;


--
-- Name: product_type_parameter_presets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_type_parameter_presets (
    id integer NOT NULL,
    group_preset_id integer NOT NULL,
    parameter_name character varying(255) NOT NULL,
    sort_order integer NOT NULL,
    preferred_unit character varying(64)
);


--
-- Name: product_type_parameter_presets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_type_parameter_presets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_type_parameter_presets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_type_parameter_presets_id_seq OWNED BY public.product_type_parameter_presets.id;


--
-- Name: product_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_types (
    id integer NOT NULL,
    key character varying(64) NOT NULL,
    label character varying(255) NOT NULL,
    supports_graph boolean NOT NULL,
    graph_kind character varying(64),
    supports_graph_overlays boolean NOT NULL,
    supports_band_graph_style boolean NOT NULL,
    graph_line_value_label character varying(128),
    graph_line_value_unit character varying(64),
    graph_x_axis_label character varying(128),
    graph_x_axis_unit character varying(64),
    graph_y_axis_label character varying(128),
    graph_y_axis_unit character varying(64)
);


--
-- Name: product_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_types_id_seq OWNED BY public.product_types.id;


--
-- Name: rpm_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rpm_lines (
    id integer NOT NULL,
    product_id integer NOT NULL,
    rpm double precision NOT NULL,
    band_color character varying(32)
);


--
-- Name: rpm_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rpm_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rpm_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rpm_lines_id_seq OWNED BY public.rpm_lines.id;


--
-- Name: rpm_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rpm_points (
    id integer NOT NULL,
    product_id integer NOT NULL,
    rpm_line_id integer NOT NULL,
    flow double precision NOT NULL,
    pressure double precision NOT NULL
);


--
-- Name: rpm_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rpm_points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rpm_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rpm_points_id_seq OWNED BY public.rpm_points.id;


--
-- Name: series; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.series (
    id integer NOT NULL,
    product_type_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description1_html text,
    description2_html text,
    description3_html text,
    comments_html text,
    template_id character varying(128)
);


--
-- Name: series_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.series_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: series_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.series_id_seq OWNED BY public.series.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    password_hash character varying(1024) NOT NULL,
    is_admin boolean NOT NULL,
    is_active boolean NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: app_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings ALTER COLUMN id SET DEFAULT nextval('public.app_settings_id_seq'::regclass);


--
-- Name: efficiency_points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.efficiency_points ALTER COLUMN id SET DEFAULT nextval('public.efficiency_points_id_seq'::regclass);


--
-- Name: product_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images ALTER COLUMN id SET DEFAULT nextval('public.product_images_id_seq'::regclass);


--
-- Name: product_parameter_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_parameter_groups ALTER COLUMN id SET DEFAULT nextval('public.product_parameter_groups_id_seq'::regclass);


--
-- Name: product_parameters id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_parameters ALTER COLUMN id SET DEFAULT nextval('public.product_parameters_id_seq'::regclass);


--
-- Name: product_type_parameter_group_presets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_type_parameter_group_presets ALTER COLUMN id SET DEFAULT nextval('public.product_type_parameter_group_presets_id_seq'::regclass);


--
-- Name: product_type_parameter_presets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_type_parameter_presets ALTER COLUMN id SET DEFAULT nextval('public.product_type_parameter_presets_id_seq'::regclass);


--
-- Name: product_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_types ALTER COLUMN id SET DEFAULT nextval('public.product_types_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.fans_id_seq'::regclass);


--
-- Name: rpm_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_lines ALTER COLUMN id SET DEFAULT nextval('public.rpm_lines_id_seq'::regclass);


--
-- Name: rpm_points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_points ALTER COLUMN id SET DEFAULT nextval('public.rpm_points_id_seq'::regclass);


--
-- Name: series id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.series ALTER COLUMN id SET DEFAULT nextval('public.series_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
20260420_000009
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_settings (id, band_graph_background_color, band_graph_label_text_color) FROM stdin;
1	#D9D9D9	#ffffff
\.


--
-- Data for Name: efficiency_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.efficiency_points (id, product_id, flow, efficiency_centre, efficiency_lower_end, efficiency_higher_end, permissible_use) FROM stdin;
3	1	417	22	\N	\N	\N
4	1	553	34	\N	\N	\N
5	1	870	66	\N	\N	\N
9	1	922	76	\N	\N	\N
12	1	0	0	\N	\N	\N
13	1	738	48	\N	\N	\N
14	1	975	87	\N	\N	\N
75	1	0	\N	\N	\N	0
78	1	244	\N	\N	\N	96
80	1	614	\N	94	\N	\N
81	1	593	\N	76	\N	\N
82	1	548	\N	58	\N	\N
85	1	338	\N	24	\N	\N
86	1	0	\N	0	\N	\N
87	1	1236	\N	\N	64	\N
88	1	1150	\N	\N	53	\N
89	1	1040	\N	\N	46	\N
90	1	951	\N	\N	36	\N
91	1	643	\N	\N	25	\N
92	1	389	\N	\N	14	\N
93	1	0	\N	\N	0	\N
16	2	383	30	\N	\N	\N
17	2	683	52	\N	\N	\N
19	2	1021	74	\N	\N	\N
20	2	0	0	0	0	0
94	2	210	\N	30	\N	\N
95	2	505	\N	60	\N	\N
96	2	807	\N	88	\N	\N
97	2	216	\N	\N	14	\N
98	2	436	\N	\N	24	\N
99	2	838	\N	\N	42	\N
100	2	1169	\N	\N	59	\N
101	2	53	\N	\N	\N	24
102	2	87	\N	\N	\N	80
103	2	103	\N	\N	\N	95
104	2	77	\N	\N	\N	48
26	3	246	24	\N	\N	\N
27	3	650	52	\N	\N	\N
29	3	898	84	\N	\N	\N
34	3	0	0	0	0	0
105	3	79	\N	\N	\N	41
107	3	127	\N	20	\N	\N
108	3	453	\N	\N	22	\N
109	3	816	\N	\N	39	\N
110	3	1096	\N	\N	61	\N
111	3	551	\N	94	\N	\N
112	3	167	\N	\N	8	\N
113	3	395	\N	52	\N	\N
35	4	0	0	0	0	0
36	4	374	31	\N	\N	\N
37	4	870	58	\N	\N	\N
38	4	1032	81	\N	\N	\N
114	4	68	\N	3	\N	\N
115	4	338	\N	17	\N	\N
116	4	775	\N	28	\N	\N
117	4	40	\N	\N	8	\N
118	4	1119	\N	54	\N	\N
119	4	428	\N	\N	52	\N
120	4	1230	\N	64	\N	\N
121	4	673	\N	\N	78	\N
122	4	784	\N	\N	92	\N
45	5	70	30	\N	\N	\N
46	5	210	42	\N	\N	\N
47	5	540	55	\N	\N	\N
48	5	690	66	\N	\N	\N
49	5	820	75	\N	\N	\N
50	5	75	31	\N	\N	\N
51	5	390	46	\N	\N	\N
52	5	720	60	\N	\N	\N
53	5	920	91	\N	\N	\N
54	5	85	33	\N	\N	\N
55	6	100	34	\N	\N	\N
56	6	360	50	\N	\N	\N
57	6	900	60	\N	\N	\N
58	6	1080	72	\N	\N	\N
59	6	1260	82	\N	\N	\N
60	6	90	33	\N	\N	\N
61	6	650	48	\N	\N	\N
62	6	1030	63	\N	\N	\N
63	6	1320	96	\N	\N	\N
64	6	105	35	\N	\N	\N
65	7	95	31	\N	\N	\N
66	7	280	43	\N	\N	\N
67	7	720	56	\N	\N	\N
68	7	890	67	\N	\N	\N
69	7	1040	77	\N	\N	\N
70	7	85	32	\N	\N	\N
71	7	520	47	\N	\N	\N
72	7	880	62	\N	\N	\N
73	7	1120	93	\N	\N	\N
74	7	100	33	\N	\N	\N
106	3	135	\N	\N	\N	97
77	1	85	\N	\N	\N	11
79	1	155	\N	\N	\N	29
76	1	206	\N	\N	\N	59
84	1	440	\N	38	\N	\N
83	1	512	\N	49	\N	\N
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_images (id, product_id, file_name, sort_order) FROM stdin;
1	1	pic_fan_1_1.png	0
3	2	pic_100_series_1.png	0
2	3	pic_afd_2200x_1.png	0
4	8	upload_8_0.jpg	0
\.


--
-- Data for Name: product_parameter_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_parameter_groups (id, product_id, group_name, sort_order) FROM stdin;
4	2	Impeller	0
5	2	Motor	1
6	2	Fan	2
10	1	Impeller	0
11	1	Motor	1
12	1	Fan	2
13	8	Silencer	0
\.


--
-- Data for Name: product_parameters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_parameters (id, group_id, parameter_name, sort_order, value_string, value_number, unit) FROM stdin;
18	4	Size	0	\N	\N	\N
19	4	Type	1	Backward curve	\N	\N
20	4	Material	2	\N	\N	\N
21	4	Motor finish	3	\N	\N	\N
22	5	Type	0	\N	\N	\N
23	5	IP Rating	1	\N	\N	\N
24	5	Insulation	2	\N	\N	\N
25	5	Power	3	\N	\N	\N
26	5	Power Supply	4	\N	\N	\N
27	5	Speed	5	\N	\N	\N
28	5	FLC	6	\N	\N	\N
29	5	Capacitor	7	\N	\N	\N
30	5	Control	8	\N	\N	\N
31	5	Protection	9	\N	\N	\N
32	6	Plate	0	\N	\N	\N
33	6	Weight	1	\N	\N	\N
34	6	Max. Temp	2	\N	\N	\N
52	10	Size	0	\N	\N	\N
53	10	Type	1	Backward curve	\N	\N
54	10	Material	2	\N	\N	\N
55	10	Motor finish	3	\N	\N	\N
56	11	Type	0	\N	\N	\N
57	11	IP Rating	1	\N	\N	\N
58	11	Insulation	2	\N	\N	\N
59	11	Power	3	\N	\N	\N
60	11	Power Supply	4	\N	\N	\N
61	11	Speed	5	\N	\N	\N
62	11	FLC	6	\N	\N	\N
63	11	Capacitor	7	\N	\N	\N
64	11	Control	8	\N	\N	\N
65	11	Protection	9	\N	\N	\N
66	12	Plate	0	\N	\N	\N
67	12	Weight	1	\N	\N	\N
68	12	Max. Temp	2	\N	\N	\N
69	13	Diameter	0	\N	1500	mm
70	13	Length	1	\N	2400	mm
71	13	Casing	2	Lock formed pre-galvanised steel sheet	\N	\N
72	13	Media	3	\N	\N	\N
73	13	Weight	4	\N	20	kg
\.


--
-- Data for Name: product_type_parameter_group_presets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_type_parameter_group_presets (id, product_type_id, group_name, sort_order) FROM stdin;
2	3	Impeller	0
3	3	Motor	1
4	3	Fan	2
5	4	Silencer	0
6	5	Controller	0
\.


--
-- Data for Name: product_type_parameter_presets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_type_parameter_presets (id, group_preset_id, parameter_name, sort_order, preferred_unit) FROM stdin;
1	2	Size	0	mm
2	2	Type	1	\N
3	2	Material	2	\N
4	2	Motor finish	3	\N
5	3	Type	0	\N
6	3	IP Rating	1	\N
7	3	Insulation	2	\N
8	3	Power	3	kW
9	3	Power Supply	4	\N
10	3	Speed	5	RPM
11	3	FLC	6	A
12	3	Capacitor	7	\N
13	3	Control	8	\N
14	3	Protection	9	\N
15	4	Plate	0	\N
16	4	Weight	1	kg
17	4	Max. Temp	2	°C
18	5	Diameter	0	mm
19	5	Length	1	mm
20	5	Casing	2	\N
21	5	Media	3	\N
22	5	Weight	4	kg
23	6	Power Supply	0	\N
24	6	Current	1	A
25	6	Mounting	2	\N
26	6	Protection	3	\N
\.


--
-- Data for Name: product_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_types (id, key, label, supports_graph, graph_kind, supports_graph_overlays, supports_band_graph_style, graph_line_value_label, graph_line_value_unit, graph_x_axis_label, graph_x_axis_unit, graph_y_axis_label, graph_y_axis_unit) FROM stdin;
3	fan	Fan	t	fan_map	t	t	RPM	RPM	Airflow	L/s	Pressure	Pa
4	silencer	Silencer	t	silencer_loss	f	f	Diameter	mm	Volume Flow	L/s	Pressure Loss	Pa
5	speed_controller	Speed Controller	f	\N	f	f	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, model, mounting_style, discharge_type, graph_image_path, show_rpm_band_shading, band_graph_background_color, band_graph_label_text_color, band_graph_faded_opacity, band_graph_permissible_label_color, product_type_id, comments_html, series_name, series_id, template_id, description1_html, description2_html, description3_html) FROM stdin;
4	VI-XR180	inline	side discharge	/home/user1/Documents/fan_graphs_website/data/product_graphs/graph_vi_xr180.png	f	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N
5	HAS-900T	\N	\N	/home/user1/Documents/fan_graphs_website/data/product_graphs/graph_has_900t.png	t	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N
6	NW-3000C	\N	\N	/home/user1/Documents/fan_graphs_website/data/product_graphs/graph_nw_3000c.png	t	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N
7	AV-M520	\N	\N	/home/user1/Documents/fan_graphs_website/data/product_graphs/graph_av_m520.png	t	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	\N
3	AFD-2200X	roof mounted	side discharge	/home/user1/Documents/fan_graphs_website/data/product_graphs/graph_afd_2200x.png	t	#ffffff	#000000	0.18	#000000	3	\N	\N	\N	product-compact	\N	\N	\N
1	Fan-1	roof mounted	vertical discharge	/home/user1/Documents/fan_graphs_website/data/product_graphs/graph_fan_1.png	t	#D9D9D9	#ffffff	0.5	#000000	3	\N	Fan - A series	1	product-default	<p>Desc1 test</p>	<p>Desc2 test</p>	<p>Desc3 test</p>
2	100 series	inline	vertical discharge	/home/user1/Documents/fan_graphs_website/data/product_graphs/graph_100_series.png	f	#D9D9D9	#ffffff	0.03	#000000	3	\N	Fan - A series	1	product-default	<h4>Description:</h4> \nRosenberg AC-Axial fans in combination with voltage-controllable external-rotor motor form a very compact, \nefficient and optimized fan unit. They impress with low installation depth and low noise level. Fast start-up is \nensured because of well-integrated components.\n \n<h4>Applications:</h4> \nAir heaters / Heat pumps / Condensers / Cooling units / Evaporators / Chillers\n \nSizes: 400, 450, 500, 560, 630mm diameter\nFan Performance: The fan is of low noise and high static efficiency design. The impeller is designed to give \nexcellent performance characteristic with high static pressure development without stall.	\N	\N
8	Splitter type	\N	\N	\N	t	#ffffff	#000000	0.18	#000000	4	\N	Silencer - A series	2	product-default	\N	\N	\N
\.


--
-- Data for Name: rpm_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rpm_lines (id, product_id, rpm, band_color) FROM stdin;
7	3	1000	\N
8	3	1500	\N
9	3	2100	\N
10	4	1400	\N
11	4	2000	\N
12	4	2600	\N
13	5	900	\N
14	5	1400	\N
15	5	2000	\N
16	6	1600	\N
17	6	2200	\N
18	6	3000	\N
19	7	1100	\N
20	7	1700	\N
21	7	2300	\N
6	2	2400	#e69100
5	2	1800	#00b371
4	2	1200	#167efe
22	1	1000	#00408f
2	1	1500	#00613d
3	1	2000	#986101
\.


--
-- Data for Name: rpm_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rpm_points (id, product_id, rpm_line_id, flow, pressure) FROM stdin;
7	1	2	537	218
8	1	2	781	197
9	1	2	1179	107
10	1	2	1336	0
12	1	3	614	297
13	1	3	977	275
14	1	3	1238	204
15	1	3	1450	0
106	1	3	1116	244
107	1	2	1091	140
16	2	4	72	94
17	2	4	293	96
18	2	4	800	80
19	2	4	958	50
20	2	4	1106	0
21	2	5	83	158
22	2	5	516	158
23	2	5	900	139
24	2	5	1186	72
25	2	5	1455	0
26	2	6	96	218
27	2	6	676	216
28	2	6	1000	178
29	2	6	1310	101
30	2	6	1640	0
32	3	7	240	85
33	3	7	650	70
34	3	7	810	45
35	3	7	950	0
37	3	8	430	135
38	3	8	780	115
39	3	8	1030	60
40	3	8	1220	0
42	3	9	583	182
43	3	9	930	160
44	3	9	1180	95
45	3	9	1490	0
46	4	10	110	120
47	4	10	350	120
48	4	10	870	100
49	4	10	1050	60
50	4	10	1230	0
51	4	11	95	185
52	4	11	610	185
53	4	11	960	150
54	4	11	1240	85
55	4	11	1500	0
56	4	12	105	255
57	4	12	720	260
58	4	12	1120	210
59	4	12	1430	120
60	4	12	1780	0
61	5	13	70	70
62	5	13	210	70
63	5	13	540	60
64	5	13	690	38
65	5	13	820	0
66	5	14	75	115
67	5	14	390	115
68	5	14	720	95
69	5	14	920	55
70	5	14	1080	0
71	5	15	85	170
72	5	15	540	175
73	5	15	860	140
74	5	15	1100	80
75	5	15	1380	0
76	6	16	100	145
77	6	16	360	145
78	6	16	900	120
79	6	16	1080	70
80	6	16	1260	0
81	6	17	90	205
82	6	17	650	205
83	6	17	1030	170
84	6	17	1320	95
85	6	17	1600	0
86	6	18	105	290
87	6	18	820	295
88	6	18	1250	235
89	6	18	1590	140
90	6	18	1960	0
91	7	19	95	90
92	7	19	280	90
93	7	19	720	75
94	7	19	890	48
95	7	19	1040	0
96	7	20	85	145
97	7	20	520	145
98	7	20	880	120
99	7	20	1120	68
100	7	20	1380	0
101	7	21	100	210
102	7	21	690	215
103	7	21	1040	175
104	7	21	1330	100
105	7	21	1660	0
113	1	22	1160	0
108	1	22	24	134
110	1	22	306	121
109	1	22	557	100
111	1	22	772	72
11	1	3	42	299
6	1	2	38	222
36	3	8	22	137
31	3	7	19	85
41	3	9	47	182
112	1	22	1081	22
\.


--
-- Data for Name: series; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.series (id, product_type_id, name, description1_html, description2_html, description3_html, comments_html, template_id) FROM stdin;
2	4	Silencer - A series	\N	\N	\N	\N	series-default
1	3	Fan - A series	Placeholder text for the description of Series A.	\N	\N	\N	series-default
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password_hash, is_admin, is_active) FROM stdin;
2	admin	pbkdf2_sha256$600000$ba2c90ed6d2455c998ea460c3a0082cc$51e148dcfe18cd25943eb9705f93f29034227e455a4e4e9aea7a89936d233913	t	t
3	vt1	pbkdf2_sha256$600000$eaf71ade45a0fb1b37b43d4a73b5fdf8$89b588ee4a2dade08bbcc140f83e605cd8f313089046fdb6b8c1db9acd3cd6b6	f	t
\.


--
-- Name: app_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.app_settings_id_seq', 1, false);


--
-- Name: efficiency_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.efficiency_points_id_seq', 122, true);


--
-- Name: fans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fans_id_seq', 8, true);


--
-- Name: product_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_images_id_seq', 4, true);


--
-- Name: product_parameter_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_parameter_groups_id_seq', 13, true);


--
-- Name: product_parameters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_parameters_id_seq', 73, true);


--
-- Name: product_type_parameter_group_presets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_type_parameter_group_presets_id_seq', 6, true);


--
-- Name: product_type_parameter_presets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_type_parameter_presets_id_seq', 26, true);


--
-- Name: product_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_types_id_seq', 5, true);


--
-- Name: rpm_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rpm_lines_id_seq', 22, true);


--
-- Name: rpm_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rpm_points_id_seq', 113, true);


--
-- Name: series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.series_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: efficiency_points efficiency_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.efficiency_points
    ADD CONSTRAINT efficiency_points_pkey PRIMARY KEY (id);


--
-- Name: products fans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fans_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_parameter_groups product_parameter_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_parameter_groups
    ADD CONSTRAINT product_parameter_groups_pkey PRIMARY KEY (id);


--
-- Name: product_parameters product_parameters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_parameters
    ADD CONSTRAINT product_parameters_pkey PRIMARY KEY (id);


--
-- Name: product_type_parameter_group_presets product_type_parameter_group_presets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_type_parameter_group_presets
    ADD CONSTRAINT product_type_parameter_group_presets_pkey PRIMARY KEY (id);


--
-- Name: product_type_parameter_presets product_type_parameter_presets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_type_parameter_presets
    ADD CONSTRAINT product_type_parameter_presets_pkey PRIMARY KEY (id);


--
-- Name: product_types product_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_types
    ADD CONSTRAINT product_types_pkey PRIMARY KEY (id);


--
-- Name: rpm_lines rpm_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_lines
    ADD CONSTRAINT rpm_lines_pkey PRIMARY KEY (id);


--
-- Name: rpm_points rpm_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_points
    ADD CONSTRAINT rpm_points_pkey PRIMARY KEY (id);


--
-- Name: series series_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_pkey PRIMARY KEY (id);


--
-- Name: series uq_series_product_type_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT uq_series_product_type_name UNIQUE (product_type_id, name);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_app_settings_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_app_settings_id ON public.app_settings USING btree (id);


--
-- Name: ix_efficiency_points_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_efficiency_points_id ON public.efficiency_points USING btree (id);


--
-- Name: ix_product_images_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_images_id ON public.product_images USING btree (id);


--
-- Name: ix_product_parameter_groups_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_parameter_groups_id ON public.product_parameter_groups USING btree (id);


--
-- Name: ix_product_parameters_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_parameters_id ON public.product_parameters USING btree (id);


--
-- Name: ix_product_type_parameter_group_presets_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_type_parameter_group_presets_id ON public.product_type_parameter_group_presets USING btree (id);


--
-- Name: ix_product_type_parameter_presets_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_type_parameter_presets_id ON public.product_type_parameter_presets USING btree (id);


--
-- Name: ix_product_types_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_types_id ON public.product_types USING btree (id);


--
-- Name: ix_product_types_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_product_types_key ON public.product_types USING btree (key);


--
-- Name: ix_products_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_products_id ON public.products USING btree (id);


--
-- Name: ix_rpm_lines_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rpm_lines_id ON public.rpm_lines USING btree (id);


--
-- Name: ix_rpm_points_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rpm_points_id ON public.rpm_points USING btree (id);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: efficiency_points efficiency_points_fan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.efficiency_points
    ADD CONSTRAINT efficiency_points_fan_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: products fk_products_series_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk_products_series_id FOREIGN KEY (series_id) REFERENCES public.series(id);


--
-- Name: product_images product_images_fan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_fan_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: product_parameter_groups product_parameter_groups_fan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_parameter_groups
    ADD CONSTRAINT product_parameter_groups_fan_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: product_parameters product_parameters_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_parameters
    ADD CONSTRAINT product_parameters_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.product_parameter_groups(id);


--
-- Name: product_type_parameter_group_presets product_type_parameter_group_presets_product_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_type_parameter_group_presets
    ADD CONSTRAINT product_type_parameter_group_presets_product_type_id_fkey FOREIGN KEY (product_type_id) REFERENCES public.product_types(id);


--
-- Name: product_type_parameter_presets product_type_parameter_presets_group_preset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_type_parameter_presets
    ADD CONSTRAINT product_type_parameter_presets_group_preset_id_fkey FOREIGN KEY (group_preset_id) REFERENCES public.product_type_parameter_group_presets(id);


--
-- Name: rpm_lines rpm_lines_fan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_lines
    ADD CONSTRAINT rpm_lines_fan_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: rpm_points rpm_points_fan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_points
    ADD CONSTRAINT rpm_points_fan_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: rpm_points rpm_points_rpm_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rpm_points
    ADD CONSTRAINT rpm_points_rpm_line_id_fkey FOREIGN KEY (rpm_line_id) REFERENCES public.rpm_lines(id);


--
-- Name: series series_product_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_product_type_id_fkey FOREIGN KEY (product_type_id) REFERENCES public.product_types(id);


--
-- PostgreSQL database dump complete
--

\unrestrict GY5HHHMYVLKo3Sc8Pn1fAU5OIAtV28e5DaGtu43gvinMzPtfu495uwmW1dOOPja

